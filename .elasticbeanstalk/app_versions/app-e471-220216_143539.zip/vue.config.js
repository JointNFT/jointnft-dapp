module.exports = {
  transpileDependencies: [
    'vuetify',
    'web3modal-vue'
  ],
  devServer: {
    disableHostCheck: true
  }
}
