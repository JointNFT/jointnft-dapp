import Moralis from "moralis";

Moralis.start({
  serverUrl: 'https://iup7yu1uewsv.usemoralis.com:2053/server',
  appId: 'u29j8VsU1usCCl1Ds3uLD6NBNt5nYHOEi4i0iFJe',
});

export default Moralis;